/* new Vivus('cog1',
    {
        duration: 150,
        type: 'sync'
    }
)
 */
