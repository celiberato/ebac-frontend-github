import '../scss/styles.scss'

const elemRoot = document.getElementById('root')
elemRoot.classList.add('container')

