cp -R ./src/assets/vendor/* ./node_modules

npm run dev