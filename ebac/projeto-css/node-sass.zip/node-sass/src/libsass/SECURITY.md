Serious about security
======================

The LibSass team recognizes the important contributions the security research
community can make. We therefore encourage reporting security issues with the
code contained in this repository.

If you believe you have discovered a security vulnerability, please report it at
https://hackerone.com/libsass instead of GitHub.

